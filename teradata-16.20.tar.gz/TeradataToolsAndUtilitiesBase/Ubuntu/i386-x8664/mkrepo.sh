#!/bin/sh
#-----------------------------------------------------------------------------------------------------------------
# File     : mkrepo.sh
# Purpose  : Setup and add TTU YUM repositories on local host
#
# Copyright 2016-2017. Teradata Corporation. All Rights Reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET.
# 
# This shell script helps customers to setup Teradata YUM repository on their web server
# This also helps to add ttu repo file to client YUM configuration
# Usage:
#	mkrepo.sh [-u server -n <destination>] [-u client -n <repourl>]
#
# History:
# 16.00.00.00	pk186048	CLNTINS-6977
# 16.10.01.00   PK186046    CLNTINS-7648 update mkrepo.sh to create the apt-get repo for Ubuntu
#-------------------------------------------------------------------------------------------------------------------

###############################################################################
# Function: display_usage
# Description: Displays the usage for this script.
# Input : None
# Output: Displays how to use this script.
# Note  : None
display_usage ()
{
  echo "Usage: $script_name [-u server -n <destination>] [-u client -n <repourl>] [-h]"
  echo "Parameters:"
  echo ""
  
  echo "[-u server -n <destination>]"
  echo "-u server        : Script will setup TTU $repo repository on local Server"
  echo "-n <destination> : Denotes absolute path of the destination folder to copy the TTU packages"
  echo "                   This <destination> must be the root folder of the web server or it should have symbolic link created to the root folder"
  echo "                   Example Web server: /var/www/html"

  echo ""
  echo "[-u client -n <repourl>]"
  echo "-u client        : Script will add existing TTU repository to $repo configuration"
  echo "-n <repourl>     : Denotes weburl from which $repo can download the TTU packages"
  echo "                   Here assumption is that TTU repository is available for download on the web server"
  echo "                   Example <repourl>: http://server-address/16.10/$PLATFORM/i386-x8664/BASE"  
  
  echo ""
  echo "If no input is given, script assumes that TTU Bundle is copied and extracted to local machine."
  echo "So script adds local TTU repository to $repo configuration"
  echo
}

###############################################################################
# Function: create_server_repo
# Description: Copies TTU packages and repodata folder to user given destination
# Input : None
# Output: NA
# Note  : None
create_server_repo ()
{
   if [ -z "${dest_baseurl}" ]; then
     echo "Provide valid destination path to copy the TTU packages"
     display_usage
     exit 1
   fi
  
   #Check if destination is a remote directory
   if [[ "${dest_baseurl}" == *"@"* ]]; then
      echo "ERROR: Destination can not be a remote folder to copy the packages. Provide local path as input"
      exit 1
   fi
  
  #check if apache web server is running
  service_status=`ps -A | grep 'apache2\|httpd'`
  if [ "$service_status" = "" ]; then
      echo "ERROR: Seems Apache web server is not running on local host. Make sure your web server is up and running before setting up the repository"	  
  fi
   
  #Check if given destination is available or not, if not create it
  if [ ! -d "${dest_baseurl}" ]; then
     mkdir -p ${dest_baseurl} 
  fi
 
  mkdir -p "${dest_baseurl}/16.10/$PLATFORM/i386-x8664/BASE"
     
  #copy ttu packages to user given detination
  copy_status="$(cp -R ${PWD}/* ${dest_baseurl}/16.10/$PLATFORM/i386-x8664/BASE)"
  if [ "$?" != "0" ]; then
     echo "ERROR: Copy $packages packages from ${PWD} to destination:${dest_baseurl}/16.10/$PLATFORM/i386-x8664/BASE failed."
	 echo "Reason: ${copy_status}"
	 exit 1
  fi
  echo "Successfully copied $packages packages from ${PWD} to destination:${dest_baseurl}/16.10/$PLATFORM/i386-x8664/BASE"
  echo "Please refresh your web server URL to check if $packages packages are available for download"
  echo "Example url: http://server-address/"
  echo "Example RPM location: http://server-address/16.10/$PLATFORM/i386-x8664/BASE"
  exit 0
}

###############################################################################
# Function: configure_repo_file
# Description: Adds TTU repo file to YUM configuration
# Input : None
# Output: NA
# Note  : None
configure_repo_file ()
{
  CHIP=`uname -i`
  OUT_REPO=/tmp/"ttu-foundation-1610.repo"
  if [ -d /etc/yum.repos.d ]; then
    echo "Use the following Yum repository file:"
    echo ""
    echo "Filename: /etc/yum.repos.d/ttu-foundation-1610.repo"
  fi
  if [ -d /etc/zypp/repos.d ]; then
    echo "Use the following Zypper repository file:"
    echo ""
    echo "Filename: /etc/zypp/repos.d/ttu-foundation-1610.repo"
  fi
  if [ -f /etc/apt/sources.list ]; then
    echo "Use the following Apt repository file:"
    echo ""
    echo "Filename: /etc/apt/sources.list"
  fi
  if [ -d /etc/yum.repos.d ] || [ -d /etc/zypp/repos.d ]; then
  		echo "-----------------------------------------------------------------"
  		echo "[ttu-foundation-1610]" > $OUT_REPO
  		echo "name=TTU Foundation 1610 i386-x8664" >> $OUT_REPO
  		#echo "#baseurl=http://server-address/path/i386-x8664" >> $OUT_REPO
  		echo "baseurl=${dest_url}" >> $OUT_REPO
  		echo "enabled=1" >> $OUT_REPO
  		echo "gpgcheck=0" >> $OUT_REPO
  		cat $OUT_REPO
  		echo "-----------------------------------------------------------------"
  		chmod 644 $OUT_REPO
  fi
  if [ -d /etc/yum.repos.d ]; then
    printf "Copy $OUT_REPO to /etc/yum.repos.d? [y/n]: "
    read input
    if [ "$input" = "y" ] || [ "$input" = "Y" ]; then
      cp $OUT_REPO /etc/yum.repos.d
    fi
  fi
  if [ -d /etc/zypp/repos.d ]; then
    printf "Copy $OUT_REPO to /etc/zypp/repos.d? [y/n]: "
    read input
    if [ "$input" = "y" ] || [ "$input" = "Y" ]; then
      cp $OUT_REPO /etc/zypp/repos.d
    fi
  fi
  if [ -f /etc/apt/sources.list ]; then
    printf "Copy $dest_url to /etc/apt/sources.list? [y/n]: "
    read input
    if [ "$input" = "y" ] || [ "$input" = "Y" ]; then
       check_repo_exists=`grep "deb $dest_url ./" /etc/apt/sources.list`
       if [ ! -z "$check_repo_exists" ]; then
           echo "This repo already exists in /etc/apt/sources.list file"
       else
          echo "deb $dest_url ./" >> /etc/apt/sources.list
       fi
    fi
  fi
}

###############################################################################
# Function: create_client_repo
# Description: Adds TTU repo file to YUM configuration
#              Here script assumes that TTU repository is configured on a web server
#               and adds that repo information to YUM configuration
# Input : None
# Output: NA
# Note  : None
create_client_repo ()
{
   if [ -z "${dest_baseurl}" ]; then
     echo "Provide server baseurl to configure $repo repository on localhost"     
     display_usage
     exit 1
   fi
   echo "Adding $dest_baseurl to $repo configuration"
   dest_url=$dest_baseurl
   configure_repo_file
}

#######################################################################################
# Function: create_client_repo
# Description: Adds TTU repo file to YUM configuration.  
#			   Here script assumes that TTU Bundle is available on local host
# Input : None
# Output: NA
# Note  : None
create_local_repo ()
{
  echo 
  echo "-------------------------------------------------------------------------------------"
  echo "No inputs are provided to the $script_name script"
  echo "So assming that Bundle(and $repo repo) is available on local host. Configuring $repo repo locally"
  echo "Would you like to continue:(y/N)? "
  read ans
  if [ $ans = "y" ] || [ $ans = "Y" ]; then
       dest_url="file://${PWD}"
       configure_repo_file
  else
       exit 1
  fi
}

###############################################################################
# Main script starts here
###############################################################################
#Get the script name for display_usage
script_name=$0

res=$(find . -type f -name *.deb)
if [ -n "$res" ]; then
        PLATFORM="Ubuntu"
        repo="apt-get"
        packages="debian"
else
		PLATFORM="Linux"
        repo="rpm"
        packages="rpm"
fi
  
url_type="local"
while getopts :u:n:h setup_args
do
  case $setup_args in
    u) url_type=$OPTARG
       ;;
    n) dest_baseurl=$OPTARG
       ;;
    h) display_usage
       exit 1
       ;;
    ?) display_usage
       exit 1
       ;;
  esac
done
shift $(($OPTIND -1))

if [ "$url_type" = "server" ]; then
   create_server_repo
elif [ "$url_type" = "client" ]; then
   create_client_repo
else
   display_usage
   create_local_repo
fi
